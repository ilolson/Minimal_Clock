/* USER CODE BEGIN Header */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <string.h>   // for memset()


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE BEGIN 0 */
#include <string.h>
#include <math.h>

// Charlieplex lines in the order you wired them:
typedef struct { GPIO_TypeDef *port; uint16_t pin; } CP_Line;
static const CP_Line cpLines[9] = {
  {GPIOA, GPIO_PIN_0},  // line 0
  {GPIOA, GPIO_PIN_1},  // line 1
  {GPIOA, GPIO_PIN_2},  // line 2
  {GPIOA, GPIO_PIN_3},  // line 3
  {GPIOA, GPIO_PIN_8},  // line 4
  {GPIOA, GPIO_PIN_9},  // line 5
  {GPIOA, GPIO_PIN_10}, // line 6
  {GPIOA, GPIO_PIN_15}, // line 7
  {GPIOB, GPIO_PIN_3}   // line 8
} ;

// Each LED is uniquely addressed by one directed pair (src→dst):
typedef struct { uint8_t src, dst; } LedPair;
static const LedPair ledPairs[72] = {
  {0,1},{0,2},{0,3},{0,4},{0,5},{0,6},{0,7},{0,8},
  {1,0},{1,2},{1,3},{1,4},{1,5},{1,6},{1,7},{1,8},
  {2,0},{2,1},{2,3},{2,4},{2,5},{2,6},{2,7},{2,8},
  {3,0},{3,1},{3,2},{3,4},{3,5},{3,6},{3,7},{3,8},
  {4,0},{4,1},{4,2},{4,3},{4,5},{4,6},{4,7},{4,8},
  {5,0},{5,1},{5,2},{5,3},{5,4},{5,6},{5,7},{5,8},
  {6,0},{6,1},{6,2},{6,3},{6,4},{6,5},{6,7},{6,8},
  {7,0},{7,1},{7,2},{7,3},{7,4},{7,5},{7,6},{7,8},
  {8,0},{8,1},{8,2},{8,3},{8,4},{8,5},{8,6},{8,7}
};
static const uint8_t circleOrder[72] = {
    // Row N2 (D1, D2), Row N3 (D3–D6), Row N4 (D7–D12), …, Row N9 (D57–D72)
     8,  0,  16,  1,  17,  9,   24,  2,  25, 10,  26, 18,
    32,  3,  33, 11,  34, 19,   35, 27,  40,  4,  41, 12,
    42, 20,  43, 28,  44, 36,   48,  5,  49, 13,  50, 21,
    51, 29,  52, 37,  53, 45,   56,  6,  57, 14,  58, 22,
    59, 30,  60, 38,  61, 46,   62, 54,  64,  7,  65, 15,
    66, 23,  67, 31,  68, 39,   69, 47,  70, 55,  71, 63
};

// prototypes
void clearAllLeds(void);
void lightLed(uint8_t index);
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();

  /* USER CODE BEGIN 2 */
  /* USER CODE BEGIN 2 */
  clearAllLeds();    // ensure every line is Hi‑Z before we start
  /* USER CODE END 2 */
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    /* USER CODE END WHILE */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
      for (uint8_t i = 0; i < 72; i++)
      {
    	     lightLed(circleOrder[i]);
          HAL_Delay(10);   // hold current LED on for 100 ms
      }
  }
  /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_5;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
	 // MX_SPI1_Init();     // make sure CubeMX generated this in spi.c/h
  // start with all off
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET);

  /*Configure GPIO pins : PA0 PA1 PA2 PA3
                           PA8 PA9 PA10 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PA4 PA5 PA6 PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF0_SPI1;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB6 PB7 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/* USER CODE BEGIN 4 */
void clearAllLeds(void)
{
    // Tri‑state every pin
    GPIO_InitTypeDef gpio = {0};
    gpio.Mode  = GPIO_MODE_INPUT;
    gpio.Pull  = GPIO_NOPULL;
    for (int i = 0; i < 9; i++)
    {
        gpio.Pin = cpLines[i].pin;
        HAL_GPIO_Init(cpLines[i].port, &gpio);
    }
}

void lightLed(uint8_t index)
{
    // 1) Hi‑Z all lines
    clearAllLeds();

    // 2) Configure source line as OUTPUT‑PP HIGH
    uint8_t src = ledPairs[index].src;
    GPIO_InitTypeDef gpio = {0};
    gpio.Pin   = cpLines[src].pin;
    gpio.Mode  = GPIO_MODE_OUTPUT_PP;
    gpio.Pull  = GPIO_NOPULL;
    gpio.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(cpLines[src].port, &gpio);
    HAL_GPIO_WritePin(cpLines[src].port, cpLines[src].pin, GPIO_PIN_SET);

    // 3) Configure sink line as OUTPUT‑PP LOW
    uint8_t dst = ledPairs[index].dst;
    gpio.Pin = cpLines[dst].pin;
    HAL_GPIO_Init(cpLines[dst].port, &gpio);
    HAL_GPIO_WritePin(cpLines[dst].port, cpLines[dst].pin, GPIO_PIN_RESET);
}


/* USER CODE END 4 */
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
