/* USER CODE BEGIN Header */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdbool.h>
#include <math.h>


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;
// LSM6DSO Register map (we only need these)
#define TWO_PI 6.28318530718
#define LSM6DSO_WHO_AM_I    0x0F
#define LSM6DSO_CTRL1_XL    0x10
#define LSM6DSO_CTRL2_G     0x11
#define LSM6DSO_CTRL3_C     0x12
#define LSM6DSO_OUTX_L_XL   0x28  // low byte of X accel
#define LSM6DSO_OUTX_L_G    0x22      // low byte of X‑gyro
#define DEG2RAD             (TWO_PI / 360.0f)
// always OR with 0x80 on multi‑byte SPI reads to auto‑increment
#define LSM6DSO_SPI_READ    0x80
#define LSM6DSO_SPI_AUTOINC 0x40

#define CS_LOW()  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET)
#define CS_HIGH() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET)

/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */
bool imu_init(void);
void imu_read_accel(float *ax, float *ay, float *az);
void imu_read_gyro(float *gx, float *gy, float *gz);



/* ---------- add near top (after prototypes) ---------------- */
static uint8_t  curIdx = 0;      // which LED is currently lit
static float    avg_ax = 0, avg_ay = 0, avg_az = 1;   // very small IIR filter
static float yaw = 0.0f;              // integrated Z‑angle in radians


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE BEGIN 0 */



// Charlieplex lines in the order you wired them:
typedef struct { GPIO_TypeDef *port; uint16_t pin; } CP_Line;
static const CP_Line cpLines[9] = {
  {GPIOA, GPIO_PIN_0},  // line 0
  {GPIOA, GPIO_PIN_1},  // line 1
  {GPIOA, GPIO_PIN_2},  // line 2
  {GPIOA, GPIO_PIN_3},  // line 3
  {GPIOA, GPIO_PIN_8},  // line 4
  {GPIOA, GPIO_PIN_9},  // line 5
  {GPIOA, GPIO_PIN_10}, // line 6
  {GPIOA, GPIO_PIN_15}, // line 7
  {GPIOB, GPIO_PIN_3}   // line 8
} ;

// Each LED is uniquely addressed by one directed pair (src→dst):
typedef struct { uint8_t src, dst; } LedPair;
static const LedPair ledPairs[72] = {
  {0,1},{0,2},{0,3},{0,4},{0,5},{0,6},{0,7},{0,8},
  {1,0},{1,2},{1,3},{1,4},{1,5},{1,6},{1,7},{1,8},
  {2,0},{2,1},{2,3},{2,4},{2,5},{2,6},{2,7},{2,8},
  {3,0},{3,1},{3,2},{3,4},{3,5},{3,6},{3,7},{3,8},
  {4,0},{4,1},{4,2},{4,3},{4,5},{4,6},{4,7},{4,8},
  {5,0},{5,1},{5,2},{5,3},{5,4},{5,6},{5,7},{5,8},
  {6,0},{6,1},{6,2},{6,3},{6,4},{6,5},{6,7},{6,8},
  {7,0},{7,1},{7,2},{7,3},{7,4},{7,5},{7,6},{7,8},
  {8,0},{8,1},{8,2},{8,3},{8,4},{8,5},{8,6},{8,7}
};
static const uint8_t circleOrder[72] = {
    // Row N2 (D1, D2), Row N3 (D3–D6), Row N4 (D7–D12), …, Row N9 (D57–D72)
     8,  0,  16,  1,  17,  9,   24,  2,  25, 10,  26, 18,
    32,  3,  33, 11,  34, 19,   35, 27,  40,  4,  41, 12,
    42, 20,  43, 28,  44, 36,   48,  5,  49, 13,  50, 21,
    51, 29,  52, 37,  53, 45,   56,  6,  57, 14,  58, 22,
    59, 30,  60, 38,  61, 46,   62, 54,  64,  7,  65, 15,
    66, 23,  67, 31,  68, 39,   69, 47,  70, 55,  71, 63
};

// prototypes
void clearAllLeds(void);
void lightLed(uint8_t index);

static inline void update_tilt_pointer(void)
{
    /* 1. Read accelerometer (in g’s) */
    float ax, ay, az;
    imu_read_accel(&ax, &ay, &az);

    /* 2. Cheap 1‑pole low‑pass – t = 0.1 gives ~10 Hz cut‑off */
    const float alpha = 0.1f;
    avg_ax = avg_ax + alpha * (ax - avg_ax);
    avg_ay = avg_ay + alpha * (ay - avg_ay);
    avg_az = avg_az + alpha * (az - avg_az);

    /* 3. Ignore Z; project onto X‑Y plane and get heading */
    float angle = atan2f(-avg_ay, avg_ax);       // 0 rad = +X, CCW positive
    if (angle < 0) angle += TWO_PI;             // 0 … 2π

    /* 4. Map heading to 0‥71  (add 0.5 for rounding) */
    uint8_t newIdx = (uint8_t)((angle * 72.0f / TWO_PI) + 0.5f) % 72;

    /* 5. If the pointer moved, update LEDs */
    if (newIdx != curIdx) {

        lightLed(circleOrder[newIdx]);
        curIdx = newIdx;
    }
}

static inline void update_yaw_pointer(void)
{
    /* wrap yaw into 0 … 2π */
    float angle = fmodf(yaw, TWO_PI);
    if (angle < 0) angle += TWO_PI;

    /* convert to 0 … 71 index */
    uint8_t newIdx = (uint8_t)((angle * 72.0f / TWO_PI) + 0.5f) % 72;

    /* light LED only if it moved */
    if (newIdx != curIdx)
    {
        lightLed(circleOrder[newIdx]);
        curIdx = newIdx;
    }
}



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */

int main(void) {
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_SPI1_Init();

  if (!imu_init()) {
    // error: blink all LEDs fast, or hang:
    while (1) {

      for (int i = 0; i < 72; i += 1)
     {
    	  lightLed(circleOrder[i]);
    	    HAL_Delay(2);
    	  lightLed(circleOrder[((i+24)%72)]);
      HAL_Delay(2);
	  lightLed(circleOrder[((i+24+24)%72)]);
      HAL_Delay(2);
     }
    }
  }




  // good -> go into tilt‐pointer mode
  while (1)
  {
      /* --- Read gyro and integrate yaw (Z‑axis) --- */
      float gx, gy, gz;
      imu_read_gyro(&gx, &gy, &gz);        // °/s
      yaw += gz * DEG2RAD * 0.05f;        // 5 ms loop‑time assumptio
      update_yaw_pointer();                // <‑‑ add this line
//update_tilt_pointer();
      HAL_Delay(5);
  }
}
    /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_5;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{
	// In MX_SPI1_Init(), *before* HAL_SPI_Init():
	__HAL_RCC_SPI1_CLK_ENABLE();

	hspi1.Instance               = SPI1;
	hspi1.Init.Mode              = SPI_MODE_MASTER;
	hspi1.Init.Direction         = SPI_DIRECTION_2LINES;
	hspi1.Init.DataSize          = SPI_DATASIZE_8BIT;
	hspi1.Init.CLKPolarity = SPI_POLARITY_HIGH;   // CPOL=1
	hspi1.Init.CLKPhase    = SPI_PHASE_2EDGE;     // CPHA=1  → mode 3
	hspi1.Init.NSS               = SPI_NSS_SOFT;
	hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;  // ~2 MHz on 32 MHz
	hspi1.Init.FirstBit          = SPI_FIRSTBIT_MSB;
	hspi1.Init.TIMode            = SPI_TIMODE_DISABLE;
	hspi1.Init.CRCCalculation    = SPI_CRCCALCULATION_DISABLE;

	if (HAL_SPI_Init(&hspi1) != HAL_OK) Error_Handler();

	HAL_GPIO_DeInit(GPIOA, GPIO_PIN_4);          // drop the AF assignment
	GPIO_InitTypeDef cs = {0};
	cs.Pin   = GPIO_PIN_4;
	cs.Mode  = GPIO_MODE_OUTPUT_PP;
	cs.Pull  = GPIO_NOPULL;
	cs.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &cs);
	CS_HIGH();

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    GPIO_InitTypeDef  GPIO_InitStruct = {0};

    // ——— CS (manual chip‑select) on PA4 ———
    GPIO_InitStruct.Pin   = GPIO_PIN_4;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
    // start high (inactive)
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);

    // SCK/MISO/MOSI on PA5/PA6/PA7 with AF5
    GPIO_InitStruct.Pin       = GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;               // or PULLDOWN on MISO if needed
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF0_SPI1;             // correct AF
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin  = GPIO_PIN_6;      // MISO
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;     // <‑‑ add
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PA0 PA1 PA2 PA3
            GPIO_InitTypeDef GPIO_Init = {0};               PA8 PA9 PA10 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB6 PB7 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);


}

/* USER CODE BEGIN 4 */
/* USER CODE BEGIN 4 */
void clearAllLeds(void)
{
    // Tri‑state every pin
    GPIO_InitTypeDef gpio = {0};
    gpio.Mode  = GPIO_MODE_INPUT;
    gpio.Pull  = GPIO_NOPULL;
    for (int i = 0; i < 9; i++)
    {
        gpio.Pin = cpLines[i].pin;
        HAL_GPIO_Init(cpLines[i].port, &gpio);
    }
}

void lightLed(uint8_t index)
{
    // 1) Hi‑Z all lines
    clearAllLeds();

    // 2) Configure source line as OUTPUT‑PP HIGH
    uint8_t src = ledPairs[index].src;
    GPIO_InitTypeDef gpio = {0};
    gpio.Pin   = cpLines[src].pin;
    gpio.Mode  = GPIO_MODE_OUTPUT_PP;
    gpio.Pull  = GPIO_NOPULL;
    gpio.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(cpLines[src].port, &gpio);
    HAL_GPIO_WritePin(cpLines[src].port, cpLines[src].pin, GPIO_PIN_SET);

    // 3) Configure sink line as OUTPUT‑PP LOW
    uint8_t dst = ledPairs[index].dst;
    gpio.Pin = cpLines[dst].pin;
    HAL_GPIO_Init(cpLines[dst].port, &gpio);
    HAL_GPIO_WritePin(cpLines[dst].port, cpLines[dst].pin, GPIO_PIN_RESET);
}





static uint8_t imu_read_reg(uint8_t reg) {
  uint8_t tx[2] = { reg | LSM6DSO_SPI_READ, 0 };
  uint8_t rx[2];
  CS_LOW();
    HAL_SPI_TransmitReceive(&hspi1, tx, rx, 2, HAL_MAX_DELAY);
  CS_HIGH();

  return rx[1];
}

static void imu_write_reg(uint8_t reg, uint8_t val) {
  uint8_t tx[2] = { reg & 0x7F, val };
  CS_LOW();
    HAL_SPI_Transmit(&hspi1, tx, 2, HAL_MAX_DELAY);
  CS_HIGH();


}
bool imu_init(void) {    imu_write_reg(LSM6DSO_CTRL3_C, 0x44);
    imu_write_reg(LSM6DSO_CTRL1_XL, 0x60);
    imu_write_reg(LSM6DSO_CTRL2_G, 0x60);

    uint8_t id = imu_read_reg(LSM6DSO_WHO_AM_I);

    // ——— VISUAL DEBUG: blink the 8 LSBs of 'id' on LEDs 0–7 ———
    for (int bit = 0; bit < 8; bit++) {
      clearAllLeds();
      if (id & (1 << bit)) {
        // light one LED per bit‑position so you can “read” the byte in binary
        lightLed(circleOrder[bit]);
      }
    }

    return (id == 0x6C);
}

void imu_read_accel(float *ax, float *ay, float *az)
{
	uint8_t header = LSM6DSO_OUTX_L_XL | LSM6DSO_SPI_READ;   // 0x88, no 0x40


    uint8_t tx[7] = { header, 0,0,0,0,0,0 };
    uint8_t rx[7] = { 0 };

    CS_LOW();                                          /* pull CS low           */
    HAL_SPI_TransmitReceive(&hspi1, tx, rx, 7, HAL_MAX_DELAY);
    CS_HIGH();                                         /* release CS            */

    /* 2️⃣  keep the unpacking exactly as you wrote — now the bytes line up */
    int16_t raw_x = (int16_t)((rx[2] << 8) | rx[1]);
    int16_t raw_y = (int16_t)((rx[4] << 8) | rx[3]);
    int16_t raw_z = (int16_t)((rx[6] << 8) | rx[5]);
    /* ±2 g → 0.061 mg/LSB = 0.061e‑3 g/LSB */
    const float g_per_lsb = 0.061e-3f;
    *ax = raw_x * g_per_lsb;
    *ay = raw_y * g_per_lsb;
    *az = raw_z * g_per_lsb;
}

void imu_read_gyro(float *gx, float *gy, float *gz)
{
    uint8_t header = LSM6DSO_OUTX_L_G | LSM6DSO_SPI_READ;     // 0xA2
    uint8_t tx[7]  = { header, 0,0,0,0,0,0 };
    uint8_t rx[7]  = { 0 };

    CS_LOW();
    HAL_SPI_TransmitReceive(&hspi1, tx, rx, 7, HAL_MAX_DELAY);
    CS_HIGH();

    int16_t raw_x = (int16_t)((rx[2] << 8) | rx[1]);
    int16_t raw_y = (int16_t)((rx[4] << 8) | rx[3]);
    int16_t raw_z = (int16_t)((rx[6] << 8) | rx[5]);

    /* ±250 dps → 8.75 mdps / LSB  = 8.75e‑3 °/s per LSB */
    /* ±250 dps → 8.75 mdps / LSB = 8.75e‑3 °/s per LSB */
    const float dps_per_lsb = 8.75e-3f;      // 0.00875 °/s per LSB
    *gx = raw_x * dps_per_lsb;
    *gy = raw_y * dps_per_lsb;
    *gz = raw_z * dps_per_lsb;
}



/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
