#ifndef __SPI_H__
#define __SPI_H__

#include "stm32l0xx_hal_spi.h"   // defines SPI_HandleTypeDef, HAL_SPI_Transmit, etc.

extern SPI_HandleTypeDef hspi1;
void MX_SPI1_Init(void);

#endif /* __SPI_H__ */
